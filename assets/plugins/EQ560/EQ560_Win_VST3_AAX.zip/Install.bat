@echo off
title EQ560 Installer - c176 Studio
echo ==================================
echo   EQ560 Audio Plugin Installer
echo   c176 Studio
echo ==================================
echo.
echo Installing VST3...
rmdir /s /q "C:\Program Files\Common Files\VST3\EQ560.vst3" 2>nul
xcopy /E /I /Y "%~dp0EQ560.vst3" "C:\Program Files\Common Files\VST3\EQ560.vst3" >nul
echo VST3 OK
echo.
echo Installing AAX...
rmdir /s /q "C:\Program Files\Common Files\Avid\Audio\Plug-Ins\EQ560.aaxplugin" 2>nul
xcopy /E /I /Y "%~dp0EQ560.aaxplugin" "C:\Program Files\Common Files\Avid\Audio\Plug-Ins\EQ560.aaxplugin" >nul
echo AAX OK
echo.
echo Done! Restart your DAW.
echo https://c176studio.github.io
pause
