@echo off
echo Installing EQ560 by c176 Studio...
echo.

:: VST3
echo Copying VST3...
if exist "C:\Program Files\Common Files\VST3\EQ560.vst3" rmdir /s /q "C:\Program Files\Common Files\VST3\EQ560.vst3"
xcopy /E /I /Y "%~dp0EQ560.vst3" "C:\Program Files\Common Files\VST3\EQ560.vst3"

:: AAX
echo Copying AAX...
if exist "C:\Program Files\Common Files\Avid\Audio\Plug-Ins\EQ560.aaxplugin" rmdir /s /q "C:\Program Files\Common Files\Avid\Audio\Plug-Ins\EQ560.aaxplugin"
xcopy /E /I /Y "%~dp0EQ560.aaxplugin" "C:\Program Files\Common Files\Avid\Audio\Plug-Ins\EQ560.aaxplugin"

echo.
echo EQ560 installed successfully!
echo Restart your DAW to scan the new plugin.
pause