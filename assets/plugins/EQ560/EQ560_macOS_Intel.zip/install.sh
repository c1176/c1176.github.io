#!/bin/bash
echo "EQ560 (Intel) - c176 Studio"
sudo rm -rf /Library/Audio/Plug-Ins/VST3/EQ560.vst3
sudo cp -r "$(dirname "$0")/EQ560.vst3" /Library/Audio/Plug-Ins/VST3/
sudo xattr -rd com.apple.quarantine /Library/Audio/Plug-Ins/VST3/EQ560.vst3
sudo codesign --force --deep --sign - /Library/Audio/Plug-Ins/VST3/EQ560.vst3
echo "Done! Restart your DAW."
echo "https://c176studio.github.io"
